/*
 * Name:
 * Email ID:  
 */

import java.util.*;

public class Q2c {
    // ****************************************************
    // Follow the instructions below to test your methods.
    public static void main(String[] args) {
        List<School> schools = new ArrayList<>(List.of(
            new School(1),
            new School(2),
            new School(3)));

        /*
         * *******************************************************************
         * The following code tests the method getStudentsWithSiblingsInSameSch.
         */
        System.out.println("Expected:5");
        System.out.println("Actual  :" + getStudentsWithSiblingsInSameSch(schools));
    
    }

    /*
     * Write the method getStudentsWithSiblingsInSameSch
     */
    public static int getStudentsWithSiblingsInSameSch(List<School> schools) {
       // insert your code here.

       return 0;
       // to make this code compile. Please modify accordingly!
    }
}
