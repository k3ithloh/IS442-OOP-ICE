import java.util.*;

public class Q1aTester extends Q1a {

    private static double score = 0;
    private static String qn = "Q1a";

    public static void main(String[] args) {
        grade();
        score = (score / 30) * 4;
        System.out.println(score);
    }

    public static void grade() {
        System.out.println("-------------------------------------------------------");
        System.out.println("---------------------- " + qn + " ----------------------------");
        System.out.println("-------------------------------------------------------");

        int tcNum = 1;
        {
            try {
                String str = "abc";
                int n = 0;
                System.out.printf("Test %d: stutter(%s, %d)%n", tcNum++, str, n);
                String expected = Q1as.stutter(str, n);
                String result = stutter(str, n);
                System.out.printf("Expected  :|%s|%n", expected);
                System.out.printf("Actual    :|%s|%n", result);
              
                if (expected.equals(result)) {
                    score += 10;
                    System.out.println("Passed");
                } else {
                    System.out.println("Failed");
                }
            } catch (Exception e) {
                System.out.println("Failed -> Exception");
                e.printStackTrace();
            }
            System.out.println("-------------------------------------------------------");    
        }

        {
            try {
                String str = "De";
                int n = 1;
                System.out.printf("Test %d: stutter(%s, %d)%n", tcNum++, str, n);
                String expected = Q1as.stutter(str, n);
                String result = stutter(str, n);
                System.out.printf("Expected  :|%s|%n", expected);
                System.out.printf("Actual    :|%s|%n", result);
              
                if (expected.equals(result)) {
                    score += 10;
                    System.out.println("Passed");
                } else {
                    System.out.println("Failed");
                }
            } catch (Exception e) {
                System.out.println("Failed -> Exception");
                e.printStackTrace();
            }
            System.out.println("-------------------------------------------------------");    
        }

        {
            try {
                String str = "BxDy";
                int n = 3;
                System.out.printf("Test %d: stutter(%s, %d)%n", tcNum++, str, n);
                String expected = Q1as.stutter(str, n);
                String result = stutter(str, n);
                System.out.printf("Expected  :|%s|%n", expected);
                System.out.printf("Actual    :|%s|%n", result);
               
                if (expected.equals(result)) {
                    score += 10;
                    System.out.println("Passed");
                } else {
                    System.out.println("Failed");
                }
            } catch (Exception e) {
                System.out.println("Failed -> Exception");
                e.printStackTrace();
            }
            System.out.println("-------------------------------------------------------");    
        }
    }
}