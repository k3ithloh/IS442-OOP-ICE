import java.util.*;

public class Q1bTester extends Q1b {

    private static double score = 0;
    private static String qn = "Q1b";

    public static void main(String[] args) {
        grade();
        score = (score / 60) * 4;
        System.out.println(score);
    }

    public static void grade() {
        System.out.println("-------------------------------------------------------");
        System.out.println("---------------------- " + qn + " ----------------------------");
        System.out.println("-------------------------------------------------------");

        int tcNum = 1;

        try {
            long[] inputs = {};
            boolean isOdd = false;
            System.out.printf("Test %d: percent(%s, %b)%n", tcNum++, Arrays.toString(inputs), isOdd);
            String expected = String.format("%.1f", Q1bs.percent(inputs, isOdd));
            String result = String.format("%.1f",percent(inputs, isOdd));
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
          
            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            long[] inputs = null;
            boolean isOdd = false;
            System.out.printf("Test %d: percent(%s, %b)%n", tcNum++, Arrays.toString(inputs), isOdd);
            String expected = String.format("%.1f", Q1bs.percent(inputs, isOdd));
            String result = String.format("%.1f",percent(inputs, isOdd));
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
        
            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
         
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            long[] inputs = {5};
            boolean isOdd = true;
            System.out.printf("Test %d: percent(%s, %b)%n", tcNum++, Arrays.toString(inputs), isOdd);
            String expected = String.format("%.1f", Q1bs.percent(inputs, isOdd));
            String result = String.format("%.1f",percent(inputs, isOdd));
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
          
            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            long[] inputs = {-15};
            boolean isOdd = true;
            System.out.printf("Test %d: percent(%s, %b)%n", tcNum++, Arrays.toString(inputs), isOdd);
            String expected = String.format("%.1f", Q1bs.percent(inputs, isOdd));
            String result = String.format("%.1f",percent(inputs, isOdd));
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
           
            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            long[] inputs = {-10, 100, 20, -5};
            boolean isOdd = true;
            System.out.printf("Test %d: percent(%s, %b)%n", tcNum++, Arrays.toString(inputs), isOdd);
            String expected = String.format("%.1f", Q1bs.percent(inputs, isOdd));
            String result = String.format("%.1f",percent(inputs, isOdd));
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
           
            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            long[] inputs = {6, 13, 19, 8, 23, 99};
            boolean isOdd = false;
            System.out.printf("Test %d: percent(%s, %b)%n", tcNum++, Arrays.toString(inputs), isOdd);
            String expected = String.format("%.1f", Q1bs.percent(inputs, isOdd));
            String result = String.format("%.1f",percent(inputs, isOdd));
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
           
            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

    }
}