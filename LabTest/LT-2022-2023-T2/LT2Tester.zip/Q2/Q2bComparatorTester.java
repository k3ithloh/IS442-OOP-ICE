import java.util.*;

public class Q2bComparatorTester extends Q2b {

    private static double score = 0;
    private static String qn = "Q2bComparator";

    public static void main(String[] args) {
        grade();
        score = (score / 10) * 1;
        System.out.println(score);
    }

    public static void grade() {
        System.out.println("-------------------------------------------------------");
        System.out.println("---------------------- " + qn + " ----------------------------");
        System.out.println("-------------------------------------------------------");

        int tcNum = 1;

        try {
            List<Product> expected = new ArrayList<>();
            expected.add(new Product("P30", 200, "vegetables"));
            expected.add(new Product("P80", 200, "toys"));
            expected.add(new Product("P50", 300, "fruits"));
            expected.add(new Product("P40", 400, "toys"));

            List<Product> result = new ArrayList<>();
            result.add(new Product("P30", 200, "vegetables"));
            result.add(new Product("P80", 200, "toys"));
            result.add(new Product("P50", 300, "fruits"));
            result.add(new Product("P40", 400, "toys"));
    
            Collections.sort(expected, new ProductComparators());
            Collections.sort(result, new ProductComparator());
            System.out.printf("Test %d: ProductComparator%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
          
            if (expected.toString().equals(result.toString())) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");
    }
}