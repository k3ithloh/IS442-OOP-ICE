import java.util.*;

public class Q2cTester extends Q2c {

    private static double score = 0;
    private static String qn = "Q2c";

    public static void main(String[] args) {
        grade();
        score = (score / 30) * 3;
        System.out.println(score);
    }

    public static void grade() {
        System.out.println("-------------------------------------------------------");
        System.out.println("---------------------- " + qn + " ----------------------------");
        System.out.println("-------------------------------------------------------");

        int tcNum = 1;

        try {
            List<Product> products = List.of(
                    new Product("P2", 780),
                    new Perishable("P3", 470, new SimpleDate(1, 6, 2024)),
                    new Product("P4", 250),
                    new Perishable("P5", 760, new SimpleDate(15, 6, 2023)),
                    new Product("P6", 250),
                    new Product("P7", 250),
                    new Perishable("P8", 760, new SimpleDate(1, 4, 2023)));

            Perishable[] expectedArr = Q2cs.getExpiringPerishables(products, 90);
            Perishable[] resultArr = getExpiringPerishables(products, 90);

            String expected = Arrays.toString(expectedArr);
            String result = Arrays.toString(resultArr);
            
            System.out.printf("Test %d: getExpiringPerishables%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            List<Product> products = List.of(
                    new Product("P10", 140),
                    new Product("P20", 780),
                    new Product("P30", 470),
                    new Product("P40", 250),
                    new Product("P80", 760));

            Perishable[] expectedArr = Q2cs.getExpiringPerishables(products,10);
            Perishable[] resultArr = getExpiringPerishables(products, 10);

            String expected = Arrays.toString(expectedArr);
            String result = Arrays.toString(resultArr);
            
            System.out.printf("Test %d: getExpiringPerishables%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            List<Product> products = List.of(
                    new Product("P1", 140),
                    new Product("P2", 780),
                    new Perishable("P3", 760, new SimpleDate()),
                    new Product("P4", 470),
                    new Product("P5", 760),
                    new Product("P7", 760));

            Perishable[] expectedArr = Q2cs.getExpiringPerishables(products, 1);
            Perishable[] resultArr = getExpiringPerishables(products, 1);

            String expected = Arrays.toString(expectedArr);
            String result = Arrays.toString(resultArr);
            
            System.out.printf("Test %d: getExpiringPerishables%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
        
            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");
    }
}