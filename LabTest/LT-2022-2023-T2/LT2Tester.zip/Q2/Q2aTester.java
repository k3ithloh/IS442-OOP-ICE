import java.util.*;

public class Q2aTester extends Q2a {

    private static double score = 0;
    private static String qn = "Q2a";

    public static void main(String[] args) {
        grade();
        score = (score / 50) * 3;
        System.out.println(score);
    }

    public static void grade() {
        System.out.println("-------------------------------------------------------");
        System.out.println("---------------------- " + qn + " ----------------------------");
        System.out.println("-------------------------------------------------------");

        int tcNum = 1;

        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');

            List<Product> products = List.of(
                    new Product("P1", 140, s1),
                    new Product("P2", 780, s1),
                    new Product("P3", 470, s1));

            Shop expected = Q2as.getCheapestShop(products, "P10");
            Shop result = getCheapestShop(products, "P10");
            System.out.printf("Test %d: getCheapestShop%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
          
            if (result == null) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");
    
        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');

            List<Product> products = List.of(
                    new Product("P1", 140, s1),
                    new Product("P1", 80, s1),
                    new Product("P1", 470, s1),
                    new Product("P2", 250, s2),
                    new Product("P2", 760, s2),
                    new Product("P3", 850, s2),
                    new Product("P3", 350, s3),
                    new Product("P3", 450, s3));
           
            Shop expected = Q2as.getCheapestShop(products, "P1");
            Shop result = getCheapestShop(products, "P1");
            System.out.printf("Test %d: getCheapestShop%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected.getName());
            System.out.printf("Actual    :%s%n", result.getName());
          
            if (expected.getName().equals(result.getName())) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");
    
        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');

            List<Product> products = List.of(
                    new Product("P1", 140, s1),
                    new Product("P2", 780, s1),
                    new Product("P3", 470, s1),
                    new Product("P1", 250, s2),
                    new Product("P2", 780, s2),
                    new Product("P3", 850, s2),
                    new Product("P1", 350, s3),
                    new Product("P2", 780, s3),
                    new Product("P3", 450, s3));
           
            Shop expected = Q2as.getCheapestShop(products, "P2");
            Shop result = getCheapestShop(products, "P2");
            System.out.printf("Test %d: getCheapestShop%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected.getName());
            System.out.printf("Actual    :%s%n", result.getName());
          
            if (expected.getName().equals(result.getName())) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");
    
        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');
            List<Product> products = List.of(
                    new Product("P1", 140, s1),
                    new Product("P2", 700, s1),
                    new Product("P3", 470, s1),
                    new Product("P1", 250, s2),
                    new Product("P2", 760, s2),
                    new Product("P3", 450, s2),
                    new Product("P1", 350, s3),
                    new Product("P2", 770, s3),
                    new Product("P3", 450, s3));
           
            Shop expected = Q2as.getCheapestShop(products, "P2");
            Shop result = getCheapestShop(products, "P2");
            System.out.printf("Test %d: getCheapestShop%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected.getName());
            System.out.printf("Actual    :%s%n", result.getName());
          
            if (expected.getName().equals(result.getName())) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");
    
        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');

            List<Product> products = List.of(
                    new Product(new String("P1"), 140, s1),
                    new Product(new String("P2"), 700, s1),
                    new Product(new String("P3"), 470, s1),
                    new Product(new String("P1"), 250, s2),
                    new Product(new String("P2"), 760, s2),
                    new Product(new String("P3"), 450, s2),
                    new Product(new String("P1"), 350, s3),
                    new Product(new String("P2"), 770, s3),
                    new Product(new String("P3"), 450, s3));
           
            Shop expected = Q2as.getCheapestShop(products, "P1");
            Shop result = getCheapestShop(products, "P1");
            System.out.printf("Test %d: getCheapestShop%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
          
            if (expected.getName().equals(result.getName())) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");   
    }
}