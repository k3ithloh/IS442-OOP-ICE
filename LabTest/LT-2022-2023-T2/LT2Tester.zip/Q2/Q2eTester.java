import java.util.*;
import java.util.stream.Collectors;

public class Q2eTester extends Q2e {

    private static double score = 0;
    private static String qn = "Q2e";

    public static void main(String[] args) {
        grade();
        score = (score / 40) * 4;
        System.out.println(score);
    }

    public static void grade() {
        System.out.println("-------------------------------------------------------");
        System.out.println("---------------------- " + qn + " ----------------------------");
        System.out.println("-------------------------------------------------------");

        int tcNum = 1;

        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');
            Shop s4 = new Shop("S4", 'W');
            List<Product> products = List.of(
                    new Product("P2", 10, s1),
                    new Product("P3", 20, s1),
                    new Product("P4", 10, s1),
                    new Product("P5", 20, s1),
                    new Product("P6", 10, s1),
                    new Product("P1", 20, s1),
                    new Product("P1", 30, s2),
                    new Product("P2", 40, s2),
                    new Product("P3", 50, s2),
                    new Product("P5", 40, s3),
                    new Product("P4", 60, s3),
                    new Product("P6", 70, s3),
                    new Product("P1", 80, s4),
                    new Product("P2", 80, s4));

            String expected = convertWithStream(Q2es.getShopsWithHighestCommonProducts(products));
            String result = convertWithStream(getShopsWithHighestCommonProducts(products));
           
            System.out.printf("Test %d: getShopsWithHighestCommonProducts%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');
            Shop s4 = new Shop("S4", 'W');
            Shop s5 = new Shop("S5", 'W');
            List<Product> products = List.of(
            new Product("P1", 10, s1),
            new Product("P2", 20, s1),
            new Product("P3", 10, s1),
            new Product("P4", 20, s1),
            new Product("P5", 10, s1),
            new Product("P6", 20, s1),
            new Product("P1", 30, s2),
            new Product("P2", 40, s2),
            new Product("P3", 50, s2),
            new Product("P5", 40, s3),
            new Product("P4", 60, s3),
            new Product("P6", 70, s3),
            new Product("P2", 80, s4),
            new Product("P1", 70, s5),
            new Product("P2", 80, s5)
            );

            String expected = convertWithStream(Q2es.getShopsWithHighestCommonProducts(products));
            String result = convertWithStream(getShopsWithHighestCommonProducts(products));
           
            System.out.printf("Test %d: getShopsWithHighestCommonProducts%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {    
            List<Product> products = List.of(
            new Product("P3", 60, new Shop("S3", 'E')),
            new Product("P1", 10, new Shop("S1", 'N')),
            new Product("P2", 60, new Shop("S3", 'E')),
            new Product("P2", 20, new Shop("S1", 'N')),
            new Product("P4", 30, new Shop("S1", 'N')),
            new Product("P1", 50, new Shop("S3", 'E')),
            new Product("P7", 50, new Shop("S7", 'E')),
            new Product("P6", 30, new Shop("S3", 'E')),
            new Product("P2", 70, new Shop("S4", 'W')),
            new Product("P3", 80, new Shop("S4", 'W')));
                
            String expected = convertWithStream(Q2es.getShopsWithHighestCommonProducts(products));
            String result = convertWithStream(getShopsWithHighestCommonProducts(products));
           
            System.out.printf("Test %d: getShopsWithHighestCommonProducts%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            List<Product> products = List.of(
            new Product(new String("P1"), 30, new Shop("S2", 'S')),
            new Product(new String("P3"), 60, new Shop("S3", 'E')),
            new Product(new String("P1"), 10, new Shop("S1", 'N')),
            new Product(new String("P2"), 60, new Shop("S3", 'E')),
            new Product(new String("P2"), 20, new Shop("S1", 'N')),
            new Product(new String("P2"), 40, new Shop("S2", 'S')),
            new Product(new String("P2"), 70, new Shop("S4", 'W')),
            new Product(new String("P1"), 50, new Shop("S3", 'E')),
            new Product(new String("P3"), 80, new Shop("S4", 'W')));

            String expected = convertWithStream(Q2es.getShopsWithHighestCommonProducts(products));
            String result = convertWithStream(getShopsWithHighestCommonProducts(products));
           
            System.out.printf("Test %d: getShopsWithHighestCommonProducts%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");
    }

    public static String convertWithStream(Map<String, ?> map) {
        String mapAsString = map.keySet().stream()
                .map(key -> key + "=" + map.get(key))
                .collect(Collectors.joining(", ", "{", "}"));
        return mapAsString;
    } // Reference : https://www.baeldung.com/java-map-to-string-conversion
}