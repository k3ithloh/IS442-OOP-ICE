import java.util.*;

public class Q2bTester extends Q2b {

    private static double score = 0;
    private static String qn = "Q2b";

    public static void main(String[] args) {
        grade();
        score = (score / 40) * 2;
        System.out.println(score);
    }

    public static void grade() {
        System.out.println("-------------------------------------------------------");
        System.out.println("---------------------- " + qn + " ----------------------------");
        System.out.println("-------------------------------------------------------");

        int tcNum = 1;

        try {
            List<Product> products = List.of(
                    new Product("P2", 100, "toys"),
                    new Product("P3", 200, "fruits"),
                    new Product("P4", 300, "fruits"),
                    new Product("P5", 400, "toys"),
                    new Product("P6", 300, "fruits"),
                    new Product("P7", 600, "snacks"),
                    new Product("P1", 400, "toys")
            );

            List<Product> expected = Q2bs.getProductsOfCategory(products, "drinks");
            List<Product> result = getProductsOfCategory(products, "drinks");
            System.out.printf("Test %d: getProductsOfCategory%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
          
            if (expected.toString().equals(result.toString())) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            List<Product> products = List.of(
                    new Product("P10", 200, "toys"),
                    new Product("P20", 300, "snacks"),
                    new Product("P30", 400, "toys"),
                    new Product("P40", 300, "fruits"),
                    new Product("P50", 100, "toys"),
                    new Product("P60", 600, "snacks"),
                    new Product("P70", 400, "toys"),
                    new Product("P80", 400, "snacks"),
                    new Product("P90", 400, "toys")
            );

            List<Product> expected = Q2bs.getProductsOfCategory(products, "snacks");
            List<Product> result = getProductsOfCategory(products, "snacks");
            System.out.printf("Test %d: getProductsOfCategory%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
          
            if (expected.toString().equals(result.toString())) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            List<Product> products = List.of(
                    new Product("P10", 200, new String("toys")),
                    new Product("P20", 300, new String("snacks")),
                    new Product("P30", 400, new String("toys")),
                    new Product("P40", 300, new String("fruits")),
                    new Product("P50", 100, new String("toys")),
                    new Product("P60", 600, new String("snacks")),
                    new Product("P70", 400, new String("toys")),
                    new Product("P80", 400, new String("snacks")),
                    new Product("P90", 400, new String("toys"))
            );

            List<Product> expected = Q2bs.getProductsOfCategory(products, "snacks");
            List<Product> result = getProductsOfCategory(products, "snacks");
            System.out.printf("Test %d: getProductsOfCategory%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
          
            if (expected.toString().equals(result.toString())) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            List<Product> products = List.of(
                    new Product("P30", 200, "vegetables"),
                    new Product("P80", 200, "toys"),
                    new Product("P40", 300, "fruits"),
                    new Product("P50", 400, "toys"),
                    new Product("P90", 300, "fruits"),
                    new Product("P60", 100, "toys"),
                    new Product("P70", 600, "snacks"),
                    new Product("P10", 400, "toys")
            );

            List<Product> expected = Q2bs.getProductsOfCategory(products, "toys");
            List<Product> result = getProductsOfCategory(products, "toys");
            System.out.printf("Test %d: getProductsOfCategory%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);
          
            if (expected.toString().equals(result.toString())) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");
    }
}