import java.util.*;
import java.util.stream.Collectors;

public class Q2dTester extends Q2d {

    private static double score = 0;
    private static String qn = "Q2d";

    public static void main(String[] args) {
        grade();
        score = (score / 50) * 4;
        System.out.println(score);
    }

    public static void grade() {
        System.out.println("-------------------------------------------------------");
        System.out.println("---------------------- " + qn + " ----------------------------");
        System.out.println("-------------------------------------------------------");

        int tcNum = 1;

        try {
            List<Product> products = List.of();

            String expected = convertWithStream(Q2ds.getTheCheapestShops(products));
            String result = convertWithStream(getTheCheapestShops(products));
            System.out.printf("Test %d: getTheCheapestShops%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');
            Shop s4 = new Shop("S4", 'W');
            Shop s5 = new Shop("S5", 'W');

            List<Product> products = List.of(
                new Product("P60", 1, s1),
                new Product("P60", 1, s2),
                new Product("P60", 1, s3),
                new Product("P80", 2, s4),
                new Product("P80", 2, s5));

            String expected = convertWithStream(Q2ds.getTheCheapestShops(products));
            String result = convertWithStream(getTheCheapestShops(products));
            System.out.printf("Test %d: getTheCheapestShops%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');
            Shop s4 = new Shop("S4", 'W');
            Shop s5 = new Shop("S5", 'W');

            List<Product> products = List.of(
                new Product("P60", 10, s1),
                new Product("P60", 3, s4),
                new Product("P60", 8, s2),
                new Product("P60", 3, s3),
                new Product("P60", 3, s5));

            String expected = convertWithStream(Q2ds.getTheCheapestShops(products));
            String result = convertWithStream(getTheCheapestShops(products));
            System.out.printf("Test %d: getTheCheapestShops%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            Shop s1 = new Shop("S1", 'N');
            Shop s2 = new Shop("S2", 'S');
            Shop s3 = new Shop("S3", 'E');
            Shop s4 = new Shop("S4", 'W');

            List<Product> products = List.of(

                    new Product(new String("P30"), 4, s1),
                    new Product(new String("P30"), 1, s3),
                    new Product(new String("P10"), 2, s2),
                    new Product(new String("P20"), 2, s1),
                    new Product(new String("P20"), 2, s2),
                    new Product(new String("P10"), 5, s1),
                    new Product(new String("P10"), 3, s4),
                    new Product(new String("P40"), 3, s3),
                    new Product(new String("P30"), 3, s2));

            String expected = convertWithStream(Q2ds.getTheCheapestShops(products));
            String result = convertWithStream(getTheCheapestShops(products));
            System.out.printf("Test %d: getTheCheapestShops%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");

        try {
            List<Product> products = List.of(
            new Product(new String("P40"), 5, new Shop("S2", 'S')),
            new Product(new String("P30"), 4, new Shop("S1", 'N')),
            new Product(new String("P30"), 1, new Shop("S3", 'E')),
            new Product(new String("P10"), 5, new Shop("S2", 'S')),
            new Product(new String("P20"), 2, new Shop("S1", 'N')),
            new Product(new String("P20"), 2, new Shop("S2", 'S')),
            new Product(new String("P10"), 5, new Shop("S1", 'N')),
            new Product(new String("P10"), 3, new Shop("S4", 'W')),
            new Product(new String("P40"), 2, new Shop("S3", 'E')),
            new Product(new String("P40"), 3, new Shop("S1", 'N')),
            new Product(new String("P30"), 3, new Shop("S2", 'S')));

            String expected = convertWithStream(Q2ds.getTheCheapestShops(products));
            String result = convertWithStream(getTheCheapestShops(products));
            System.out.printf("Test %d: getTheCheapestShops%n", tcNum++);
            System.out.printf("Expected  :%s%n", expected);
            System.out.printf("Actual    :%s%n", result);

            if (expected.equals(result)) {
                score += 10;
                System.out.println("Passed");
            } else {
                System.out.println("Failed");
            }
        } catch (Exception e) {
            System.out.println("Failed -> Exception");
            e.printStackTrace();
        }
        System.out.println("-------------------------------------------------------");
    }

    public static String convertWithStream(Map<String, ?> map) {
        String mapAsString = map.keySet().stream()
                .map(key -> key + "=" + map.get(key))
                .collect(Collectors.joining(", ", "{", "}"));
        return mapAsString;
    } // Reference : https://www.baeldung.com/java-map-to-string-conversion
}