// this is for Q8
public class Counter {


}