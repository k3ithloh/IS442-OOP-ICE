public class VehicleTest {
    public static void main(String[] args) {
        Motorcycle m = new Motorcycle(200.0);

        Car c = new Car(50);

        System.out.println(m);
        System.out.println(c);

    }
}
