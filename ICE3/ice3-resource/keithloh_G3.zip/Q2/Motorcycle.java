public class Motorcycle extends Vehicle {

    public Motorcycle(double distancePerLiter) {
        super(2, distancePerLiter);
    }
}
