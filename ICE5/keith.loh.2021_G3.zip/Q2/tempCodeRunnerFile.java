
    Octagon o = new Octagon(12);