
public class OctagonTest {
  
  public static void main(String[] args) {
    Octagon o = new Octagon(12);

    // System.out.println("Printing side length now");
    // System.out.println(o.getSide());

    // System.out.println("Printing area now");
    // System.out.println(o.getArea());

    System.out.println(o.toString());
  }
}
