java -cp "classes:lib/*" app/TemplatingEngine
# java -cp "classes:lib/*" sourceFiles/*