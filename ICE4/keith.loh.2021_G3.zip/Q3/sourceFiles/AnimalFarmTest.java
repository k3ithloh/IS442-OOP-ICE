import farming.AnimalFarm;

public class AnimalFarmTest {
    public static void main(String[] args) {
        AnimalFarm farm = new AnimalFarm();
        farm.makeNoise();
    }
}
