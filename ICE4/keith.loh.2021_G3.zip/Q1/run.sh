#! Mac/Linux
java -cp classes farming.app.AnimalFarmTest
# java -cp <dependencies> <package> <classname>

# ! Windows
# java -cp "library/*;classes" ticketing.test.TicketUtilityTest
# java -cp <dependencies> <package> <classname>