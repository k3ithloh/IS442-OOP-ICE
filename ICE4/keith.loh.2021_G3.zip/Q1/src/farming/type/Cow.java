package farming.type;

public class Cow implements Animal {
    @Override
    public void makeNoise() {
        System.out.println("moo moo");
    }
}
