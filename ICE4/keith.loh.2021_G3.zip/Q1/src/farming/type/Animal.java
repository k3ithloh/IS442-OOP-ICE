package farming.type;

public interface Animal {
    public void makeNoise();
}
