java -cp "ben_code;download;my_compiled;" smu/bidding/App

# ! Why does this not work? Shouldnt it work as I need to direct it to the App.class and it is in my_compiled/smu/bidding/App.class
# java -cp "ben_code;download;my_compiled;" my_compiled/smu/bidding/App